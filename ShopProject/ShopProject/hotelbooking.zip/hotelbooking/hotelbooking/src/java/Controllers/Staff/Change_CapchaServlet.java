/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package Controllers.Staff;

import DAL.Add_StaffDao;
import DAL.LoginDAO;
import Models.CaptchaInfo;
import Utils.CaptchaStore;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author admin
 */
public class Change_CapchaServlet extends HttpServlet {
   
    private static final long serialVersionUID = 1L;

    private ConcurrentHashMap<String, CaptchaInfo> captchaStore = CaptchaStore.getInstance();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ChangeServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ChangeServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String encodedCaptcha = request.getParameter("encodedCaptcha");


        if (encodedCaptcha != null && captchaStore.containsKey(encodedCaptcha)) {
            CaptchaInfo captchaInfo = captchaStore.get(encodedCaptcha);  
            if (captchaInfo.isExpired()) {
                captchaStore.remove(encodedCaptcha); // Remove expired captcha
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Captcha has expired.");
            } else {
                request.setAttribute("capcha", captchaInfo.getCaptcha());
                request.setAttribute("email", captchaInfo.getEmail());
                request.setAttribute("encodedCaptcha", encodedCaptcha);
                request.getRequestDispatcher("Views/Login/change_capcha.jsp").forward(request, response);
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid captcha.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String passworda = request.getParameter("passworda");
        String password = request.getParameter("password");
        String captcha = request.getParameter("captcha");
        String email = request.getParameter("email");
        String encodedCaptcha = request.getParameter("encodedCaptcha");
        
        Add_StaffDao staffDAO = new Add_StaffDao();     
        // Check if passwords match
        if (!password.equals(passworda)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Passwords do not match.");
            return;
        }

   
        if (captcha == null || !CaptchaStore.getInstance().get(encodedCaptcha).getCaptcha().equals(captcha) || !CaptchaStore.getInstance().get(encodedCaptcha).getEmail().equals(email)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid or expired captcha.");
            return;
        }
        

        boolean passwordChanged = staffDAO.changePasswordByEmail(email, password);

        if (passwordChanged) {        
            captchaStore.remove(captcha);
            request.getRequestDispatcher("Views/Login/change_capcha.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to add staff.");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
