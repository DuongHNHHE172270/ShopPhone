/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;

import Models.Role;
import Models.Staff;
import java.security.MessageDigest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class StaffDao extends DBContext {

    public List<Staff> getActiveStaff() {
        List<Staff> staffList = new ArrayList<>();
        String sql = "SELECT * FROM Staff WHERE status = 'active'";
        try {
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                int staff_id = rs.getInt("staff_id");
                int staff_type_id = rs.getInt("staff_type_id");
                String email = rs.getString("email");
                String password = rs.getString("password");
                String status = rs.getString("status");
                Role role = getRoleById(staff_type_id);
                Staff staff = new Staff(staff_id, role, email, password, status);
                staffList.add(staff);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return staffList;
    }

    private Role getRoleById(int staff_type_id) {
        String sql = "SELECT * FROM Role WHERE staff_type_id = ?";
        try {
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, staff_type_id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("staff_type_id");
                String type = rs.getString("type");
                return new Role(id, type);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Staff> getInactiveStaff() {
        List<Staff> staffList = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Staff WHERE status = 'inactive'";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Staff staff = new Staff();
                staff.setStaff_id(rs.getInt("staff_id"));
                staff.setEmail(rs.getString("email"));
                staff.setPassword(rs.getString("password"));
                staff.setStatus(rs.getString("status"));
                staff.setStaff_type_id(getRoleById(rs.getInt("staff_type_id")));
                staffList.add(staff);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return staffList;
    }

    public boolean insert(Staff staff) throws Exception {
        String sql = "INSERT INTO Staff (staff_type_id, email, password, status) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, staff.getStaff_type_id().getStaff_type_id());
            pst.setString(2, staff.getEmail());
            pst.setString(3, hashPassword(staff.getPassword()));
            pst.setString(4, staff.getStatus());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Role> getAllRoles() {
        List<Role> roles = new ArrayList<>();
        String sql = "SELECT * FROM Role";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("staff_type_id");
                String type = rs.getString("type");
                roles.add(new Role(id, type));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return roles;
    }
    
    private String hashPassword(String password) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedHash = digest.digest(password.getBytes());

        StringBuilder hexString = new StringBuilder(2 * encodedHash.length);
        for (byte b : encodedHash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }

        return hexString.toString();
    }
}
